@echo off
REM Duplo clique neste arquivo para instalar a extensao.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-extensao.ps1"
