# instalar-extensao.ps1
# Instalador da extensão da empresa.
# Detecta navegadores instalados, deixa a pessoa escolher em quais
# instalar, baixa a extensão do GitHub e guia a instalação em cada
# navegador (o processo exato muda por navegador — ver README.md).

# ============================================================
# CONFIGURE AQUI antes de distribuir:
# Troque pelo link do SEU repositório (baixa a branch/tag como .zip)
# Exemplo: "https://github.com/SEU_USUARIO/SEU_REPO/archive/refs/heads/main.zip"
# ============================================================
$RepoZipUrl = "COLOQUE_AQUI_O_LINK_DO_ZIP_DO_GITHUB"
$NomeExtensao = "Extensao da Empresa"

$ErrorActionPreference = "Stop"
$pastaDestino = "$env:LOCALAPPDATA\ExtensoesEmpresa\$($NomeExtensao -replace ' ','')"

Write-Host ""
Write-Host "=== Instalador: $NomeExtensao ===" -ForegroundColor Cyan
Write-Host ""

if ($RepoZipUrl -eq "COLOQUE_AQUI_O_LINK_DO_ZIP_DO_GITHUB") {
    Write-Host "ERRO: edite este arquivo e coloque o link do seu repositório no GitHub em `$RepoZipUrl." -ForegroundColor Red
    Write-Host "Exemplo: https://github.com/SEU_USUARIO/SEU_REPO/archive/refs/heads/main.zip"
    Read-Host "Pressione ENTER para sair"
    exit 1
}

# ------------------------------------------------------------
# 1) Detectar navegadores instalados
# ------------------------------------------------------------
function Test-Navegador($caminhos) {
    foreach ($c in $caminhos) {
        if (Test-Path $c) { return $true }
    }
    return $false
}

$navegadores = @{}
$navegadores["Chrome"]  = Test-Navegador @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
)
$navegadores["Edge"]    = Test-Navegador @(
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
)
$navegadores["Firefox"] = Test-Navegador @(
    "$env:ProgramFiles\Mozilla Firefox\firefox.exe",
    "${env:ProgramFiles(x86)}\Mozilla Firefox\firefox.exe"
)

Write-Host "Navegadores encontrados nesta máquina:"
$i = 1
$mapaOpcoes = @{}
foreach ($nome in $navegadores.Keys) {
    $status = if ($navegadores[$nome]) { "encontrado" } else { "não encontrado" }
    $cor = if ($navegadores[$nome]) { "Green" } else { "DarkGray" }
    Write-Host "  [$i] $nome — $status" -ForegroundColor $cor
    if ($navegadores[$nome]) { $mapaOpcoes["$i"] = $nome }
    $i++
}
Write-Host ""

# ------------------------------------------------------------
# 2) Escolha do usuário
# ------------------------------------------------------------
Write-Host "Digite os números dos navegadores onde quer instalar (ex: 1,2) ou 'todos':"
$escolha = Read-Host ">"

$selecionados = @()
if ($escolha.Trim().ToLower() -eq "todos") {
    $selecionados = $mapaOpcoes.Values
} else {
    foreach ($n in $escolha -split ",") {
        $n = $n.Trim()
        if ($mapaOpcoes.ContainsKey($n)) { $selecionados += $mapaOpcoes[$n] }
    }
}

if ($selecionados.Count -eq 0) {
    Write-Host "Nenhum navegador válido selecionado. Saindo." -ForegroundColor Yellow
    Read-Host "Pressione ENTER para sair"
    exit 1
}

Write-Host ""
Write-Host "Selecionado(s): $($selecionados -join ', ')" -ForegroundColor Cyan

# ------------------------------------------------------------
# 3) Baixar a extensão do GitHub
# ------------------------------------------------------------
Write-Host ""
Write-Host "Baixando a extensão do GitHub..."
$zipTemp = "$env:TEMP\extensao-empresa.zip"

Invoke-WebRequest -Uri $RepoZipUrl -OutFile $zipTemp -UseBasicParsing

if (Test-Path $pastaDestino) { Remove-Item $pastaDestino -Recurse -Force }
New-Item -ItemType Directory -Path $pastaDestino -Force | Out-Null

$pastaTemp = "$env:TEMP\extensao-empresa-extraida"
if (Test-Path $pastaTemp) { Remove-Item $pastaTemp -Recurse -Force }
Expand-Archive -Path $zipTemp -DestinationPath $pastaTemp -Force

# O GitHub compacta com uma subpasta "repo-nome-da-branch" dentro do zip.
# Aqui pegamos o conteúdo de dentro dela.
$subpasta = Get-ChildItem $pastaTemp | Select-Object -First 1
Copy-Item "$($subpasta.FullName)\*" $pastaDestino -Recurse -Force

Write-Host "Extensão baixada em: $pastaDestino" -ForegroundColor Green

# Copia o caminho pra área de transferência — facilita colar na tela do navegador
Set-Clipboard -Value $pastaDestino

# ------------------------------------------------------------
# 4) Instalar em cada navegador escolhido
#    (cada navegador tem um processo próprio — não existe um
#    jeito único "instale em qualquer navegador")
# ------------------------------------------------------------
foreach ($nav in $selecionados) {
    Write-Host ""
    Write-Host "--- $nav ---" -ForegroundColor Cyan

    switch ($nav) {
        "Chrome" {
            Write-Host "O caminho da extensão já está copiado (Ctrl+V) na área de transferência."
            Write-Host "1. O Chrome vai abrir na tela de extensões."
            Write-Host "2. Ative 'Modo do desenvolvedor' (canto superior direito)."
            Write-Host "3. Clique em 'Carregar sem compactação' e cole o caminho (Ctrl+V)."
            Start-Process "chrome.exe" "chrome://extensions"
        }
        "Edge" {
            Write-Host "O caminho da extensão já está copiado (Ctrl+V) na área de transferência."
            Write-Host "1. O Edge vai abrir na tela de extensões."
            Write-Host "2. Ative 'Modo de desenvolvedor' (menu à esquerda)."
            Write-Host "3. Clique em 'Carregar' (Load unpacked) e cole o caminho (Ctrl+V)."
            Start-Process "msedge.exe" "edge://extensions"
        }
        "Firefox" {
            Write-Host "O caminho do arquivo manifest.json já está copiado (Ctrl+V)."
            Write-Host "1. O Firefox vai abrir na tela de depuração de extensões."
            Write-Host "2. Clique em 'Carregar extensão temporária' (Load Temporary Add-on)."
            Write-Host "3. Navegue até a pasta e selecione o arquivo manifest.json."
            Write-Host "AVISO: no Firefox normal, essa instalação é temporária e some ao reiniciar" -ForegroundColor Yellow
            Write-Host "o navegador. Para instalação permanente sem loja, veja a seção" -ForegroundColor Yellow
            Write-Host "'Firefox permanente' no README.md." -ForegroundColor Yellow
            Set-Clipboard -Value "$pastaDestino\manifest.json"
            Start-Process "firefox.exe" "about:debugging#/runtime/this-firefox"
        }
    }
}

Write-Host ""
Write-Host "Concluído. Siga as instruções que abriram em cada navegador." -ForegroundColor Green
Read-Host "Pressione ENTER para fechar"
