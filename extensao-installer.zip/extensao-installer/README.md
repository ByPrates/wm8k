# Instalador de Extensão — Chrome / Edge / Firefox

## O que tem aqui

- **extensao-exemplo/** — uma extensão de teste (bem simples) só pra validar
  o fluxo todo funcionando antes de trocar pela extensão de verdade.
  Quando estiver pronto, apague o conteúdo desta pasta e coloque os
  arquivos da sua extensão real no lugar (o `manifest.json` tem que
  ficar na raiz da pasta).
- **installer/instalar-extensao.ps1** — o script que faz o trabalho:
  detecta navegadores, pergunta onde instalar, baixa do GitHub e abre
  a tela certa em cada navegador.
- **installer/Instalar Extensao.bat** — atalho de duplo-clique que
  roda o script acima (bat sozinho não faz nada sofisticado, só chama
  o PowerShell).

## Como colocar no ar

1. Suba esta pasta inteira pro seu repositório no GitHub.
2. Pegue o link de download da branch como zip. Formato:
   ```
   https://github.com/SEU_USUARIO/SEU_REPO/archive/refs/heads/main.zip
   ```
   (troque `SEU_USUARIO`, `SEU_REPO` e `main` pelo nome real da branch)
3. Abra `installer/instalar-extensao.ps1` e cole esse link na linha:
   ```powershell
   $RepoZipUrl = "COLOQUE_AQUI_O_LINK_DO_ZIP_DO_GITHUB"
   ```
4. Suba de novo pro GitHub com essa alteração.
5. Distribua o `Instalar Extensao.bat` (junto com o `.ps1`, ele precisa
   estar na mesma pasta) pras pessoas — é só dar duplo-clique.

## O que acontece quando alguém roda

1. O script olha a máquina e mostra quais navegadores existem (Chrome,
   Edge, Firefox).
2. A pessoa digita os números dos navegadores desejados (ou "todos").
3. O script baixa o zip do seu repositório, extrai numa pasta fixa
   (`%LOCALAPPDATA%\ExtensoesEmpresa\...`) e copia o caminho da pasta
   pra área de transferência.
4. Pra cada navegador escolhido, ele abre a tela de extensões certa e
   mostra as 2-3 instruções finais (ativar modo desenvolvedor, colar
   o caminho, etc.) — a pessoa só precisa colar (Ctrl+V) e clicar.

## Por que não é 100% automático (e por que isso é normal)

Cada navegador tem seu próprio mecanismo de segurança pra evitar que
qualquer programa instale extensão sozinho sem o usuário perceber —
por isso não existe um "instalador universal silencioso" de verdade.
O que este script faz é eliminar quase todo o trabalho manual (achar
a pasta, navegar até ela, etc.), deixando só 1-2 cliques finais por
navegador.

## Se quiser evoluir para instalação realmente silenciosa (modo empresa)

Isso existe, mas dá mais trabalho de configurar uma vez:

- **Chrome/Edge:** dá pra forçar a instalação sem nenhum clique via
  política de grupo (chave de registro `ExtensionInstallForcelist`),
  mas isso exige hospedar um "manifesto de atualização" (arquivo XML)
  em algum lugar acessível pela rede, além de empacotar a extensão
  como `.crx` assinado. É mais robusto, porém precisa de infraestrutura
  extra que não montamos aqui ainda.
- **Firefox:** dá pra tornar a instalação permanente (sem sumir ao
  reiniciar) via arquivo `policies.json` do Firefox, mas o Firefox
  "normal" (não ESR) exige que a extensão seja assinada pela Mozilla
  ou que a verificação de assinatura seja desativada via política —
  o que é uma configuração de segurança que vale avaliar com cuidado
  antes de aplicar em várias máquinas.

Se em algum momento você quiser seguir por esse caminho mais avançado,
me chama que a gente monta essa parte também.

## Testando antes de distribuir

Antes de mandar pro time todo, rode você mesmo o `.bat` numa máquina
de teste com a `extensao-exemplo/` (sem trocar nada ainda) só pra
confirmar que o fluxo de download + abertura do navegador está
funcionando. Depois é só trocar o conteúdo da pasta pela extensão
real e testar de novo.
